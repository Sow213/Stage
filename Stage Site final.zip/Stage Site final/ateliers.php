<?php 
session_start(); 

// Gestion des informations utilisateur
$prenom = $_SESSION['prenom'] ?? 'Invité';
$nom = $_SESSION['nom'] ?? '';
$type = ($_SESSION['classe'] ?? '') === 'PROF' ? 'prof' : '';

// Connection à MySQL
include('parametreBDD.php');
if (!isset($bdd)) {
    die("Erreur : Connexion à la base de données non établie.");
}

// Requête pour récupérer les ateliers
$requete = "SELECT * FROM actions WHERE nombre > 0 AND nombre < 1000 AND numero > 0 AND numero < 444 ORDER BY numero ASC"; // Changement ici
$result = $bdd->query($requete);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Les Ateliers - 10 Avril 2025</title>
    <link rel="icon" href="images/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="style1.css">

    <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
        	<li><a href="maintenance.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
        </ul>
    </nav>
</head>
<body>
    <!-- Contenu principal -->
    <div class="container mt-5">
        <header class="text-center mb-4">
            <h1 class="display-4" style="font-size: 2rem;">
                <?php if ($nom && $prenom) { ?>
                    Bonjour, <?= htmlspecialchars($prenom . ' ' . $nom); ?>. 
                <?php } ?>
                Découvrez les ateliers du 10 avril 2025.
            </h1>
        </header>

        <section class="row">
            <?php while ($row = $result->fetch()) { ?>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <img src="images/<?= htmlspecialchars($row['numero']); ?>.jpg" class="card-img-top" alt="Image de l'atelier">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($row['numero'] . ' - ' . $row['nom']); ?></h5>
                            <p class="card-text">
                                <strong>Type :</strong> <?= htmlspecialchars($row['type']); ?><br>
                                <strong>Salle :</strong> <?= htmlspecialchars($row['salle']); ?><br>
                                <strong>Places disponibles :</strong> <?= htmlspecialchars($row['nombre']); ?><br>
                                <?php if (!empty($row['intervenant'])) { ?>
                                    <strong>Intervenant :</strong> <?= htmlspecialchars($row['intervenant']); ?><br>
                                <?php } ?>
                            </p>
                            <p class="card-text"><?= htmlspecialchars($row['description']); ?></p>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <?php $result->closeCursor(); ?>
        </section>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
		© 2025 La Journée du 10 Avril. Tous droits réservés. 
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
</footer>

    <script src="bootstrap.bundle.min.js"></script>
</body>
</html>
