<?php session_start(); 
if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type = 'prof';        
} else {
    header('Location: index.html');
    echo 'Accès refusé';
}

// Connexion à MySQL
include('parametreBDD.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" type="text/css" href="style1.css">
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>

<body>
    <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
            <li><a href="gestionnaire.php" style="color: white; text-decoration: none; padding: 10px 20px;">Gestion</a></li>
            <li><a href="deconnexion.php">Déconnexion</a></li>

        </ul>
    </nav>

    <div id="bloc_page">
        <header>
            <h1>Bonjour professeur <?php echo $prenom.' '.$nom; ?></h1>
        </header>

        <section>
            <form method="post" name="classe" action="classe.php">
                <h2>Sélectionner la classe pour voir les inscriptions</h2>
                <select name="classe">
                    <?php include('listeclasse.php'); ?>
                </select>
                <input type="submit" value="Valider"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="classe" action="fiche_eleve.php">
                <h2>Imprimer les fiches élèves d'une classe</h2>
                <select name="classe">
                    <?php include('listeclasse.php'); ?>
                </select>
                <input type="submit" value="Valider"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="atelier" action="fiche_atelier.php">
                <h2>Sélectionner un atelier pour imprimer la liste</h2>
                <select name="numero">
                    <?php 
                    $requete = "SELECT * from actions";
                    $result = $bdd->query($requete);
                    while ($row = $result->fetch()) {
                        echo '<option value="'.$row['numero'].'">'.$row['numero'].'</option>';
                    }
                    $result->closeCursor();
                    ?>
                </select>
                <input type="submit" value="Valider"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="atelier" action="ateliers.php">
                <h2>Sélectionner un atelier pour voir le remplissage</h2>
                <select name="numero">
                    <?php 
                    $requete = "SELECT * from actions";
                    $result = $bdd->query($requete);
                    while ($row = $result->fetch()) {
                        echo '<option value="'.$row['numero'].'">'.$row['numero'].'</option>';
                    }
                    $result->closeCursor();
                    ?>
                </select>
                <input type="submit" value="Valider"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="recherche" action="recherche.php">
                <h2>Faire une recherche pour inscription</h2>
                <input type="text" name="mot" placeholder="Ex : Machin ou 110 ou Pauline" size="30"/>
                <input type="submit" value="Rechercher"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="atelier" action="nouveau.php">
                <h2>Créer un nouvel élève (vérifiez qu'il n'existe pas déjà)</h2>
                <input type="submit" value="C'est parti"/>
            </form>

            <h2>OU</h2>

            <form method="post" name="problemes" action="problemes.php">
                <h2>Voir les élèves dont l'inscription est incomplète</h2>
                <input type="submit" value="C'est parti"/>
            </form>

            <?php 
            if ($_SESSION['classe'] == 'PROF' && $_SESSION['nom'] == 'MARQUET') {
                echo '
                    <h2>OU</h2>
                    <form method="post" name="maj" action="atelierMAJ.php">
                        <h2>Mettre à jour les ateliers</h2>
                        <input type="submit" value="Mettre à jour"/>
                    </form>
                    <h2>OU</h2>
                    <form method="post" name="maj" action="expoMAJ.php">
                        <h2>Mettre à jour les expositions</h2>
                        <input type="submit" value="Mettre à jour"/>
                    </form>
                ';
            }
            ?>
        </section>
    </div>
</body>
</html>
