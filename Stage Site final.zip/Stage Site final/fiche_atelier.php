<?php session_start(); 
if ($_SESSION['classe']=='PROF') {
    $nom = $_SESSION['nom'];	
    $prenom = $_SESSION['prenom'];
    $type='prof';		
} else {
    header('Location: index.html');
    exit();
}

// On récupère les données du formulaire
$numero = $_POST['numero'];

// Connexion à la base de données
include('parametreBDD.php');

// Mettre à jour les effectifs des ateliers
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/logo.jpg" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
            <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>
        </ul>
    </nav>
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <header>
        <h1>Bonjour professeur <?php echo $prenom.' '.$nom; ?></h1>
    </header>
    <div id="bloc_page">
        <section>
            <form method="post" name="nouvelle_action" action="fiche_atelier.php">
                <align="center"> 
                    <?php 
                    echo 'Numero';
                    // On récupère les actions proposées 
                    $requete = "SELECT * FROM actions ORDER BY numero"; 
                    $result = $bdd->query($requete); 
                    ?> 
                    <select name="numero">
                        <?php while ($row = $result->fetch()) { ?> 
                            <option value="<?php echo $row['numero']; ?>" <?php if ($row['numero'] == $numero) { ?> selected="selected" <?php } ?>> 
                                <?php echo $row['numero']; ?>
                            </option> 
                        <?php } ?>
                    </select>
                    <input type="hidden" name="nom" value="<?php echo $nom ?>" />
                    <input type="hidden" name="prenom" value="<?php echo $prenom ?>" />
                    <input type="submit" value="Valider"/>
                </align>
            </form>
        </section>
        
        <?php 
        if ($numero == 0) {  
            $requete = "SELECT * FROM actions WHERE nombre > 0 AND nombre < 1000 AND numero > 1 ORDER BY numero";	
            $result = $bdd->query($requete); 
            while ($row2 = $result->fetch()) { 
                $nom_atelier = $row2['nom'];
                $M1 = $row2['M1']; $M2 = $row2['M2']; $S1 = $row2['S1'];
                $nombre = $row2['nombre'];
                $occupationM1 = $row2['occupationM1'];
                $occupationM2 = $row2['occupationM2'];
                $occupationS1 = $row2['occupationS1'];
                $numero2 = $row2['numero'];
                ?> 
                <h2>Pour l'atelier : <?php echo $numero2.' / '.$nom_atelier; ?></h2>
                <?php 
                $creneaux = ['M1' => $M1, 'M2' => $M2, 'S1' => $S1];
                foreach ($creneaux as $creneau => $value) {
                    if ($value == $creneau) {
                        $requete2 = "SELECT * FROM eleves WHERE $creneau = $numero2"; 
                        $result2 = $bdd->query($requete2); 
                        ?>
                        <table>
                            <tr>
                                <td class="ligne1">
                                    <?php echo 'Les inscripts en '.$creneau.' : ';?><strong><?php echo ${'occupation'.$creneau}.'/'.$nombre; ?></strong>
                                </td>
                                <td>
                                    Emargement:
                                </td>
                            </tr>
                            <tr>	
                                <td>
                                    <?php
                                    $i = 0;
                                    while ($row3 = $result2->fetch()) {
                                        $i = $i + 1; 
                                        echo $i.'--'.$row3['nom'].'  '.$row3['prenom'].' '.$row3['classe']; ?> </br> <?php 
                                    }
                                    $result2->closeCursor();
                                    ?> 
                                </td>
                                <td>
                                </td>
                            </tr>
                        </table>
                        </br>
                        <?php 
                    } 
                }
            }
            $result->closeCursor();				
        } else {	
            // On récupère les éléments de l'atelier
            $requete = "SELECT * FROM actions WHERE numero = '$numero'"; 
            $result = $bdd->query($requete); 
            $row = $result->fetch();
            $nom_atelier = $row['nom'];
            $M1 = $row['M1']; $M2 = $row['M2']; $S1 = $row['S1'];
            $nombre = $row['nombre'];
            $occupationM1 = $row['occupationM1'];
            $occupationM2 = $row['occupationM2'];
            $occupationS1 = $row['occupationS1'];
            $result->closeCursor();
            ?>
            <h1>Voici le remplissage de l'atelier:</h1>
            <h2><?php echo $numero.' : '.$nom_atelier; ?></h2>
            <?php 
            $creneaux = ['M1' => $M1, 'M2' => $M2, 'S1' => $S1];
            foreach ($creneaux as $creneau => $value) {
                if ($value == $creneau) {
                    $requete = "SELECT * FROM eleves WHERE $creneau = $numero"; 
                    $result = $bdd->query($requete); 
                    ?>
                    <table>
                        <tr>
                            <td class="ligne1">
                                <?php echo 'Les inscripts en '.$creneau.' : ';?><strong><?php echo ${'occupation'.$creneau}.'/'.$nombre; ?></strong>
                            </td>
                            <td>
                                Emargement:
                            </td>							
                        </tr>
                        <tr>
                            <td>
                                <?php
                                $i = 0;
                                while ($row3 = $result->fetch()) {
                                    $i = $i + 1; 
                                    echo $i.'--'.$row3['nom'].'  '.$row3['prenom'].' '.$row3['classe']; ?> </br> <?php 
                                }
                                $result->closeCursor();
                                ?>  
                            </td>	
                            <td>
                            </td>
                        </tr>
                    </table>
                    </br>
                    <?php 
                } 
            }
        } ?>
    </div>
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>
            LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE<br>
            Adresse : 49 avenue du Comminges 31270 CUGNAUX<br>
            Téléphone : +33 5 61 72 75 40
        </p>
    </footer>
</body>	
</html>