<?php session_start(); 	
	// Connection à mysql
	include('parametreBDD.php');
	// fin de la partie connexion
	// on récupère les infos du formulaire
	if ($_SESSION['classe']=='PROF') 
			{
				$nom = $_SESSION['nom'];	
				$prenom = $_SESSION['prenom'];
				$type='prof';		
			} 
			else 
			{
				header('Location: index.html');
			}
	$nome = htmlspecialchars($_POST['nome']);
	$prenome = htmlspecialchars($_POST['prenome']);
	$mdpe = htmlspecialchars($_POST['mdpe']);
	$classe = htmlspecialchars($_POST['classe']);
	$login = htmlspecialchars($_POST['login']);
	$mdp = htmlspecialchars($_POST['mdp']);
	?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta charset="utf-8" />
	<title>Sur les traces de 14 18</title>
	<meta http-equiv="content-language" content="fr" />
	<meta http-equiv="content-Type" content="text/html;charset=iso-8859-15" />
	<link rel="stylesheet" type="text/css" href="style5.css">
</head>
<body>
	<?php 
	// test pour voir s'il existe déjà
	$requete="SELECT * from eleves WHERE nom='$nome' AND prenom='$prenome' " ; // requête proprement dite 
	$result = $bdd->query($requete); // envoi de la requête 
	$i =0;
	while ($row=$result->fetch()) { $i=$i+1;}
	$result->closeCursor();
	// test pour voir SI LE MOT DE PASSE EST BON
	$requete="SELECT * from eleves WHERE nom='PROFTEST' " ; // requête proprement dite 
	$result = $bdd->query($requete); // envoi de la requête 	
	$row=$result->fetch();
	$mdp2=$row['mdp'];	
	$result->closeCursor();
	if ($mdp2 == $mdpe) 
		{
		if ($i == 0) 
			{	
				// on insere le nouveau
				$requete2="INSERT INTO eleves (classe,nom,prenom,login,mdp,M1,M2,S1) VALUES ('$classe','$nome','$prenome','$login','$mdp','0','0','0')"; // requête proprement dite 
				$result2 = $bdd->query($requete2);// envoi de la requête
				$result2->closeCursor();
				?> <h2> L élève <?php echo $nome.' '.$prenome.' a bien été créé dans la classe '.$classe; ?></h2>
				<form method = "post" name = "atelier" action="prof.php">
					<align="center"><input type="submit" value="Retour page professeur"/>
				</form> <?php
			}
			else
			{?> <h2> <?php echo $nome.' '.$prenome.' existe déjà !'; ?> </h2> <?php 
				$requete="SELECT * from eleves WHERE nom='$nome' AND prenom='$prenome' " ; // requête proprement dite 
				$result = $bdd->query($requete); // envoi de la requête while ($row=mysql_fetch_array($result))
				while ($row=$result->fetch())
					{?>
						<table>
							<tr>
								<td> <?php echo 'nom :'.$row['nom']; ?> </td>
								<td> <?php echo 'prenom:'.$row['prenom']; ?> </td>
								<td> <?php echo 'classe:'.$row['classe']; ?> </td>
								<td>
									<form method = "post" name = "atelier" action="nouveau.php">
										<align="center"> 
										<input type="submit" value="Retour creation de compte"/>
									</form>
								</td>
							</tr>
						</table>
						<?php
					}
				$result->closeCursor();
			}
		}
		else
		{ ?> 
		<h1> MAUVAIS MOT DE PASSE </h1> <?php 
		}?>			
	</body>
</html>